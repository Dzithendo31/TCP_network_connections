import socket
import time
import hashlib
import sys
import os
from tkinter import filedialog

IP = socket.gethostbyname(socket.gethostname())
#IP = "196.47.222.220"
Port = 4000
add = (IP, Port)
FORMAT = "utf-8"
SIZE = 1024
buffer = 1024
#
#handling argument


def main():
    #handili CML argument
    print(len(sys.argv))
    if len(sys.argv) == 3:
        IP = sys.argv[0]
        Port = sys.argv[1]
        add = (IP,Port)
    else:
        IP = socket.gethostbyname(socket.gethostname())
        #IP = "196.47.222.220"
        Port = 4000
        add = (IP, Port)
        
    try:
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect(add)
    except:
        print("Connection to user Failed....Try again later")
        return
    
    #now the connection has been established(if)
    #inserts the log in part
    #this allows user to enter 
    print("****LOG IN or Create Account****")
    name = input("Enter name: ")
    passWord = input("Enter pin Key: ")
    #genrate a key for your files to be locked
    passWord = name+str(passWord)
    print(f"Name:{name},passWord:{passWord}")

    #for every upload with protection the user will only use on passWord
    while True:

        if len(sys.argv) == 3:
            cmd = sys.argv[2]
            cmd =cmd[0]
        else:
            cmd = ""
            cmd = input("enter command to send to server:\n'd' download\n'u' Upload\n'X' delete file\n'l' To list files\n'q' to Quit\n " )
        
        if cmd == "u" or cmd == "U":
            #call the upload method to send the file to the Server.
            upload(client,passWord)

        elif cmd == "l" or cmd == "L":
            #the program will query the server connected using the query method
            query(client)
        elif cmd == "d" or cmd == "D":
            #this will call the download when the user would like to download stuff
            download(client,passWord)
  
        elif cmd == "X" or cmd == "x":
            #call the delete function to delete the method
            delete(client,passWord)
        
        else:
            "Incorrect Input, connection Lost"
            client.close()
            break
#delete a file that exist in the server
def delete(client,passWord):
    #check if the file exist and also if the pinCOde is correct
    filename = input('Enter filename: ')
    client.send(f"delete%{filename}%{passWord}".encode(FORMAT))
    msg = client.recv(SIZE).decode(FORMAT)
    if msg == "NONE":
        print("File not found or You don't have access to the File")
    else:
        print(f"File {filename} deleted")
        #wait for message and break

#this is the query method
def query(client):
    #sends a message header showing that client would like to query server
    client.send("query%none%000".encode(FORMAT))

    #this message will recieve the message of all the files in the server
    msg = client.recv(2000).decode(FORMAT)
    print("{:25}".format("Name") + "  State")
    #print out the message in the user's terminall
    print(msg)


def upload(client,passWord):
    #make a call to get fine name
    path = filedialog.askopenfilename()
    pathArr = path.split("/")
    file_name = pathArr[-1]
            #process the filename to get path seperated from the filename.
            
    state = input("Would you like to protect the file(Y/N)")
    if state == "N" or state == "n":
        client.send(f"upload%{file_name}%O".encode(FORMAT))
    elif state == "Y" or state == "y":
        #if the user requires 
        client.send(f"upload%{file_name}%C@{passWord}".encode(FORMAT))
    else:
        print("Incorrect input.")
        return
    msg = client.recv(64).decode(FORMAT)
    print(f"[SEVER]:\n{msg}")
    
    #main part of the uploading 
    #get file size
    file_size = os.path.getsize(path)
    #2A
    client.send(str(file_size).encode(FORMAT))
    sent = 0 #bytes

    print("uploading......")
    with open(path, 'rb') as f:

        while sent<file_size:

            bytes_read = f.read(1096)
            client.sendall(bytes_read)

            #get the hash for the specific bytes being sent
            file_hash = hashlib.sha256(bytes_read).hexdigest()
            #send the hash to the server
            client.sendall(file_hash.encode())

            #wait for the servers response on 
            msd = client.recv(SIZE).decode(FORMAT)
            if msd == "Continue":
                sent += 1096
                continue
            else:
                print("File disturedbed")
                break
        #just for message controls 
        control = client.recv(SIZE).decode(FORMAT)

def download(client,passWord):
    file_name = input('Enter filename: ')
    pin = input("Enter pin key locking File, 0 if none: ")
    client.send(f"download%{file_name}%{pin}".encode(FORMAT))
      
    msg = client.recv(SIZE).decode(FORMAT)
    if msg == "NONE":
        print("File not found or Incorrect Key for File Access")
    #this will either be Sending or NOT Found
            #but before it downloads it has to check
    else:
        try:
            #download(filename,client)
            #the actual downloading part
            print("Choose directory to save at")
            #ask user to choose directory to save at
            save_path = filedialog.askdirectory()
            client.send("Send File".encode(FORMAT))

            SizeX = int(client.recv(SIZE).decode(FORMAT))
            #data = bytes(data, encoding='utf-8')
            sent = 0
            with open(f"{save_path}/{file_name}", 'wb') as f:
            
                print("Downloading")
                while sent<SizeX:
                    data = client.recv(1096)#.decode(FORMAT)
                
                    computed_file_hash = hashlib.sha256(data).hexdigest()
                    hash = client.recv(64).decode(FORMAT)
                    if hash == computed_file_hash:
                        sent += 1096
                        f.write(data)
                        client.send("Continue".encode(FORMAT))
                    else:
                    #delete file
                        os.remove(f"data/{file_name}")
                        client.send("Corrupt".encode(FORMAT))
                        break

                f.close()

            print("[CLIENT] Filename Data received")
            client.send("File data received".encode(FORMAT))
            
        except:
            print("Error from server.")
            return



if __name__ == '__main__':
    main()