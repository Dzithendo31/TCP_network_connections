import socket
import hashlib
import os
import ssl
#from tkinter import filedialog

IP = socket.gethostbyname(socket.gethostname())
Port = 4001
add = (IP, Port)
FORMAT = "utf-8"
SIZE = 1024
buffer = 1024

def main():
    myClient = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    myClient.connect(add)

    myCommand = ""
    while myCommand.upper() != "E":
        myCommand = input("[U]pload \n[D]ownload \n[De]lete \n[L]isting \n[E]nd \nSelect Action Request: ")

        if myCommand.upper() == "U":
            myFile = input("Enter file name: ")
            #myFile = filedialog.askopenfilename()
            #myFile = myFile.split("/")[-1]
            myLock = input("Lock File ([Y]es/[N]o): ")
            if myLock.upper() == "N":
                myClient.send(f"upload%{myFile}%O".encode(FORMAT))
            elif myLock.upper() == "Y":
                lockKey = input("Enter files lock key: ")
                myClient.send(f"upload%{myFile}%C@{lockKey}".encode(FORMAT))
            else:
                print("Input incorrect!")
            try:
                serverMessage = myClient.recv(64).decode(FORMAT)
                print(f"SERVER MESSAGE:\n{serverMessage}")
                upload(myClient, myFile)
            except:
                print("Error Occured, restart client.")
        elif myCommand.upper() == "D":
            myFile = input("Enter file name: ")
            lockKey = input("Enter lock key.[0] if one: ")
            myClient.send(f"download%{myFile}%{lockKey}".encode(FORMAT))

            serverMessage = myClient.recv(SIZE).decode(FORMAT)
            if serverMessage == "NONE":
                print("[Access denied] Invalid File Name or Key.")
            
            else:
                try:
                    download(myClient, myFile)
                
                except:
                    print("Error downloading file.")
                
        elif myCommand.upper() == "L":
            myClient.send("query%none%000".encode(FORMAT))
            serverMessage = myClient.recv(SIZE).decode(FORMAT)
            print("{:25}".format("Name")+"   State  Size")
            print(serverMessage)
        
        elif myCommand.upper() == "DE":
            myFile = input("Enter file name: ")
            lockKey = input("Enter lock key.[0] if one: ")
            myClient.send(f"delete%{myFile}%{lockKey}".encode(FORMAT))
            serverMessage = myClient.recv(SIZE).decode(FORMAT)

            if serverMessage == "NONE":
                print("[Delete failed] Invalid File Name or Key.")
            else:
                print(f"File {myFile} Deleted.")
        elif myCommand.upper() == "E":
            print("System Exit.")
            myClient.close()
        else:
            print("Incorrect Input, Try Again.")
    
def upload(myClient, myFile):
    fileSize = os.path.getsize(myFile)
    myClient.send(str(fileSize).encode(FORMAT))
    print("[UPLOAD IN PROGRESS.]")
    sentBytes = 0
    
    with open(myFile, "rb") as f:
        while sentBytes < fileSize:
            fileBytes = f.read(1096)
            myClient.sendall(fileBytes)
            fileHash = hashlib.sha256(fileBytes).hexdigest()
            myClient.sendall(fileHash.encode())

            serverMessage1 = myClient.recv(SIZE).decode(FORMAT)
            if serverMessage1 == "Continue":
                sentBytes += 1096
            else:
                print("File Transfer Disturbed.")

def download(myClient, myFile):
    print("Trying to download.")
    myClient.send("Filename received".encode(FORMAT))
    fileSize = int(myClient.recv(SIZE).decode(FORMAT))
    receivedBytes = 0
    with open(f"downloads/{myFile}", "wb") as f:
        print("[DOWNLOAD IN PROGRESS.]")
        while receivedBytes < fileSize:
            data = myClient.recv(1096)
            fileHash = hashlib.sha256(data).hexdigest()
            fileHash1 = myClient.recv(64).decode(FORMAT)
            if fileHash1 == fileHash:
                receivedBytes += 1096
                f.write(data)
                myClient.send("Continue".encode())
            else:
                os.remove(f"data/{myFile}")
                myClient.send("Corruct".encode(FORMAT))
                break
        f.close()
    print("Download Successful.")
    myClient.send("File data received".encode(FORMAT))

if __name__ == '__main__':
    main()